﻿namespace ParkingServis
{
    public class Automobil : Vozilo
    {
        public Automobil(string registracija, string vlasnik)
            : base(registracija, vlasnik)
        {
        }

        public override double IzracunajCenu(int sati)
        {
            return sati * 100;
        }
    }
}   