﻿namespace ParkingServis
{
    public class Kamion : Vozilo
    {
        public Kamion(string registracija, string vlasnik)
            : base(registracija, vlasnik)
        {
        }

        public override double IzracunajCenu(int sati)
        {
            return sati * 250;
        }
    }
}