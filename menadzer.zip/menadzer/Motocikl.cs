﻿namespace ParkingServis
{
    public class Motocikl : Vozilo
    {
        public Motocikl(string registracija, string vlasnik)
            : base(registracija, vlasnik)
        {
        }

        public override double IzracunajCenu(int sati)
        {
            return sati * 70;
        }
    }
}