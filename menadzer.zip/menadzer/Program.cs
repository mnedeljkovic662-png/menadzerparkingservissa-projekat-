﻿using System;
using System.Collections.Generic;

namespace ParkingServis
{
    class Program
    {
        static void Main()
        {
            List<Vozilo> vozila = new List<Vozilo>();

            while (true)
            {
                Console.WriteLine("\n1 Dodaj  2 Prikazi  3 Naplati  4 Izlaz");
                string izbor = Console.ReadLine();

                if (izbor == "1")
                {
                    Console.Write("Reg: ");
                    string reg = Console.ReadLine();

                    Console.Write("Vlasnik: ");
                    string vlasnik = Console.ReadLine();

                    Console.WriteLine("1 Auto 2 Kamion 3 Motor");
                    string tip = Console.ReadLine();

                    if (tip == "1")
                        vozila.Add(new Automobil(reg, vlasnik));
                    else if (tip == "2")
                        vozila.Add(new Kamion(reg, vlasnik));
                    else if (tip == "3")
                        vozila.Add(new Motocikl(reg, vlasnik));
                }
                else if (izbor == "2")
                {
                    foreach (var v in vozila)
                        Console.WriteLine(v.Registracija + " " + v.Vlasnik);
                }
                else if (izbor == "3")
                {
                    Console.Write("Reg: ");
                    string reg = Console.ReadLine();

                    Console.Write("Sati: ");
                    int sati = int.Parse(Console.ReadLine());

                    foreach (var v in vozila)
                    {
                        if (v.Registracija == reg)
                        {
                            Console.WriteLine("Cena: " + v.IzracunajCenu(sati));
                            vozila.Remove(v);
                            break;
                        }
                    }
                }
                else if (izbor == "4")
                {
                    break;
                }
            }
        }
    }
}