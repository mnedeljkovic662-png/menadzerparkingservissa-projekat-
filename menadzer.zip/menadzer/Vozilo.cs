﻿using System;

namespace ParkingServis
{
    public abstract class Vozilo
    {
        public string Registracija { get; set; }
        public string Vlasnik { get; set; }
        public DateTime VremeUlaska { get; set; }

        public Vozilo(string registracija, string vlasnik)
        {
            Registracija = registracija;
            Vlasnik = vlasnik;
            VremeUlaska = DateTime.Now;
        }

        public abstract double IzracunajCenu(int sati);
    }
}