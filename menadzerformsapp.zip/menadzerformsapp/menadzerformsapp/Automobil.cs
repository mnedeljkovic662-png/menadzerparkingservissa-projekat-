﻿namespace menadzerformsapp
{
    public class Automobil : Vozilo
    {
        public Automobil(string r, string v) : base(r, v) { }

        public override double Cena(int sati)
        {
            return sati * 100;
        }
    }
}