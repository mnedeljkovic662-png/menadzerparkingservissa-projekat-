﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace menadzerformsapp
{
    public partial class Form1 : Form
    {
        List<Vozilo> vozila = new List<Vozilo>();

        public Form1()
        {
            InitializeComponent();
        }

        // DODAJ
        private void button1_Click(object sender, EventArgs e)
        {
            string reg = txtRegistracija.Text;
            string vlasnik = txtVlasnik.Text;
            string tip = cmbTip.Text;

            if (reg == "" || vlasnik == "" || tip == "")
            {
                MessageBox.Show("Popuni sve!");
                return;
            }

            if (tip == "Automobil")
                vozila.Add(new Automobil(reg, vlasnik));
            else if (tip == "Kamion")
                vozila.Add(new Kamion(reg, vlasnik));
            else if (tip == "Motocikl")
                vozila.Add(new Motocikl(reg, vlasnik));

            txtRegistracija.Clear();
            txtVlasnik.Clear();
            cmbTip.SelectedIndex = -1;
        }

        // PRIKAZI
        private void button2_Click(object sender, EventArgs e)
        {
            lstVozila.Items.Clear();

            foreach (var v in vozila)
            {
                lstVozila.Items.Add(v.Registracija + " | " + v.Vlasnik);
            }
        }

        // NAPLATI
        private void button3_Click(object sender, EventArgs e)
        {
            if (lstVozila.SelectedIndex == -1)
            {
                MessageBox.Show("Izaberi vozilo!");
                return;
            }

            if (txtSati.Text == "")
            {
                MessageBox.Show("Unesi sate!");
                return;
            }

            int sati;
            if (!int.TryParse(txtSati.Text, out sati))
            {
                MessageBox.Show("Sati moraju biti broj!");
                return;
            }

            Vozilo v = vozila[lstVozila.SelectedIndex];

            double cena = v.Cena(sati);

            MessageBox.Show("Naplata: " + cena + " din");

            vozila.RemoveAt(lstVozila.SelectedIndex);
            lstVozila.Items.RemoveAt(lstVozila.SelectedIndex);
        }
    }
}