﻿namespace menadzerformsapp
{
    public class Kamion : Vozilo
    {
        public Kamion(string r, string v) : base(r, v) { }

        public override double Cena(int sati)
        {
            return sati * 250;
        }
    }
}