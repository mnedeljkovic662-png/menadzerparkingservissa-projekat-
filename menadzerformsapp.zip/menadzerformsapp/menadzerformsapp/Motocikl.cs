﻿namespace menadzerformsapp
{
    public class Motocikl : Vozilo
    {
        public Motocikl(string r, string v) : base(r, v) { }

        public override double Cena(int sati)
        {
            return sati * 70;
        }
    }
}