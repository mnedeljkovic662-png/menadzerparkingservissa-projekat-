﻿namespace menadzerformsapp
{
    public abstract class Vozilo
    {
        public string Registracija { get; set; }
        public string Vlasnik { get; set; }

        public Vozilo(string registracija, string vlasnik)
        {
            Registracija = registracija;
            Vlasnik = vlasnik;
        }

        public abstract double Cena(int sati);
    }
}